const mongoose = require('mongoose');
const schemaName = new mongoose.Schema({
    name: {
        type: String
    },
    age: {
        type: Number
    }
}, {timestamps: true})

//YOU CAN ADD MIDDLEWARE UNDER HERE

const Schema = mongoose.model('Students', schemaName);
module.exports = Schema;