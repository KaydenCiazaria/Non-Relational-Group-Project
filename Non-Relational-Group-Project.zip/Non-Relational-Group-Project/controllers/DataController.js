
// made by bryant

const DataModel = require('../model/StudentModel'); //Import sampleModel from Model folder
const factory = require('./handlerFactory');
const catchAsync = require("../utils/catchAsync");

exports.get_all = factory.getAll(DataModel); // factory.(choose_function)(Model)
exports.delete_all = factory.deleteAll(DataModel); // factory.(choose_function)(Model)
exports.create_one = factory.createOne(DataModel); // factory.(choose_function)(Model)
exports.mass_create = catchAsync(async (req, res, next) => {
    await DataModel.deleteMany();
    const data = req.body;
    await DataModel.create(data);
    // console.log(data);
    res.status(201).json({
        status: 'success'
    })
})

exports.query = catchAsync(async (req, res, next) => {
    // const data = await DataModel.create({ // this is create
    //         name: "Chris",
    //         age: 21
    // });

    // const data = await DataModel.find(); // this is read

    // const data = await DataModel.findOneAndUpdate( // this is update
    //     { name: "Chris" }, // Find the document with this condition
    //     { age: 22 }, // Update the field(s) you want
    //     { new: true } // Return the updated document
    //   );
    //   console.log(data);

    const data = await DataModel.findOneAndDelete({ name: "Chris" }); // this delete
    console.log(data);


    res.status(200).json({
        status: 'success',
        data: data
    })
})